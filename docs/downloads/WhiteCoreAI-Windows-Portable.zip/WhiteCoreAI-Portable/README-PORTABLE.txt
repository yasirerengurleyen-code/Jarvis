Bu dosyaları WhiteCoreAI proje köküne kopyalayın (main.py ile aynı klasör), sonra start-jarvis.bat çalıştırın.
